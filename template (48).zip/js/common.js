head.ready(function() {

	// scroll-to
	(function() {
	    $('.scroll-to').on('click', function(event) {
	    	var _this = $(this),
	    		href = _this.attr('href'),
	    		posTop = $(href).offset().top;
	    	$('html, body').animate({
	    		scrollTop: posTop
	    	}, 500, 'swing', function () {
	    		window.location.hash = href;
	    	});
	    	event.preventDefault();
	    });
	}());

	// load json
	var data = [];
	$.ajax({
		url: '/source/2/172/data.json',
		dataType: 'json',
		data: data,
		success: callback
	});
	function callback (data) {
		$('.countries_list').append('<option class="select__item" value="Еще не определился">Еще не определился</option>');
		for (var item in data) {
			$('.js-countries').append('<a class="js-country" href="' + data[item].id + '" data-country="' + data[item].code + '">' + data[item].name + '</a>');
			$('.countries_list').append('<option class="select__item" value="' + data[item].name + '">' + data[item].name + '</option>');
		}
		$('.countries_list').append('<option class="select__item" value="Другая">Другая</option>');

		var countries = $('.js-country');
		
		countries.on('click', function () {
			var _this = $(this),
				id = _this.attr('href');
			if (!_this.hasClass('is-active')) {
				if ($('body').hasClass('is-loaded')) {
					var posTop = $('.js-reg').offset().top;
					$('html, body').animate({
						scrollTop: posTop
					}, 500);
				};
				$('body').addClass('is-loaded');
				$('.js-country').removeClass('is-active');
				_this.addClass('is-active');
				for (var item in data) {
					if (item == id) {
						// bg
						$('.js-reg').css('background-image', 'url(' + data[item].background + ')');
						$('.js-info').empty();
						// info
						for (var text in data[item].content) {
							$('.js-info').append('<tr></tr>');
							$.each(data[item].content[text], function( key, value ) {
								$('.js-info tr').last().append('<td>' + value + '</td>');
							});
						}
					};
				}
			};
			return false;
		});

		var current = countries.first();
		if (wl.queryParams && wl.queryParams.country) {
			var country = $(".js-country[data-country='" + wl.queryParams.country + "']")
			if (country.length) {
				current = country;
			}
		}
		current.trigger('click');
	};

});
// $(document).ready(function(){ 
// $("body").on("click",".phone__text",function(){ 
// $('.cbh-icon-anim1').click(); 
// }); 
// });