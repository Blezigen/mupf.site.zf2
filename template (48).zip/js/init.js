head.load("js/lib/jquery.js", 
		 "js/lib/bootstrap.min.js",
		 "js/lib/validator.js",
		 "js/common.js");
