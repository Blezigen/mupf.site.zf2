head.ready(function() {

	// scroll-to

	(function() {
	    $('.scroll-to').on('click', function(event) {

	    	var _this = $(this),
	    		href = _this.attr('title');
					if ( $(document).scrollTop() < 93) {
		    		posTop = $(href).offset().top - 60;
					} else{
						posTop = $(href).offset().top;
					}
	    	$('html, body').animate({
	    		scrollTop: posTop
	    	}, 500, 'swing', function () {
	    		window.location.hash = href;
	    	});
	    	event.preventDefault();
	    });
	}());

	// slider range
	(function () {
		var range = $('.js-range'),
			el = range.find('.js-range-el'),
			clients = range.find('.js-range-clients'),
			check = range.find('.js-range-check'),
			checkValue = check.html(),
			checkValue = checkValue.replace(/\s/g, ''),
			revenue = range.find('.js-range-revenue'),
			profit = range.find('.js-range-profit');
			usn = range.find('.js-range-usn');
			usnValue = usn.html(),
			usnValue = usnValue.replace(/\s/g, ''),
			trud = range.find('.js-range-trud');
			trudValue = trud.html(),
			trudValue = trudValue.replace(/\s/g, ''),
			arenda = range.find('.js-range-arenda');
			arendaValue = arenda.html(),
			arendaValue = arendaValue.replace(/\s/g, ''),

			percent = range.find('.js-range-percent');
			percentValue = percent.html(),
			percentValue = percentValue.replace(/\s/g, ''),


		el.slider({
			range: 'min',
			value: 6,
			min: 1,
			max: 10,
			step: 1,
			slide: function(event, ui) {
				var clientsValue = ui.value,
					revenueValue = clientsValue * 15000000;

					usnVal = revenueValue*0.006;

					personalValue = (30000+60000+revenueValue*0.004)*1.3;
				 	profitValue = (revenueValue*percentValue*0.01)*0.94-personalValue-arendaValue;

					usnVal = usnVal.toFixed().replace(/(\d{1,3})(?=((\d{3})*)$)/g, " $1");
					personalValue = personalValue.toFixed().replace(/(\d{1,3})(?=((\d{3})*)$)/g, " $1");
					revenueValue = revenueValue.toFixed().replace(/(\d{1,3})(?=((\d{3})*)$)/g, " $1");
					profitValue = profitValue.toFixed().replace(/(\d{1,3})(?=((\d{3})*)$)/g, " $1");

					usn.html(usnVal);
					trud.html(personalValue);
			  	revenue.html(revenueValue);
					profit.html(profitValue);
			}
		});

	}());

	(function() {
	    $("input[name=phone]").intlTelInput();
	}());



	/***  [:::::] ***/
	 $(".h3.link").click(function() {
		if( $(this).parents('.bayan-block').hasClass('active')){
			$(this).parents('.bayan-block').removeClass('active');
			$(this).parents('.bayan-block').addClass('inactive');
		} else {
			$(this).parents('.bayan-block').removeClass('inactive');
			$(this).parents('.bayan-block').addClass('active');
		}
  });

	$(".faq-link-bayan").click(function() {
		if( $(this).parents('.faq-bayan-block').hasClass('active')){
			$('.faq-bayan-block').removeClass('active');
			$(this).parents('.faq-bayan-block').removeClass('active');
		}else{
			$('.faq-bayan-block').removeClass('active');
			$(this).parents('.faq-bayan-block').addClass('active');
		}
	});


	var str="";
	$("input[name='name']").on('change', function() {
	  $('.success-message').empty();
	  str = $(this).val() + ", НАШИ МЕНЕДЖЕРЫ УЖЕ ЗАНИМАЮТСЯ ВАШЕЙ ЗАЯВКОЙ.";
	  //alert(str);
	  $('.success-message').prepend(str);
	});

	/*** fixed menu ***/
	$(function(){
	    $(window).scroll(function() {
	        var top = $(document).scrollTop();
	        if (top > 93) {
	          $('.navbar-default').addClass('fixedclass').animate('easy');
	        } else {
	          $('.navbar-default').removeClass('fixedclass').animate('easy');
	        }
	    });
	});




	$('.callback').on('click', function() {
	  $('#myModal form').attr('data-goal', 'callback');
	});
	$('.calculate').on('click', function() {
		$('#presentation form').attr('data-goal', 'calculate');
	});
	$('.Tarif700').on('click', function() {
		$('#descr form').attr('data-goal', 'Tarif700');
	});
	$('.Tarif1700').on('click', function() {
		$('#descr form').attr('data-goal', 'Tarif1700');
	});
	$('.Tarif6000').on('click', function() {
		$('#descr form').attr('data-goal', 'Tarif6000');
	});
	$('.vopros').on('click', function() {
		$('#manager form').attr('data-goal', 'vopros');
	});
	$('.present').on('click', function() {
		$('#presentation form').attr('data-goal', 'present');
	});

	$('.shema').on('click', function() {
		$('#shema form').attr('data-goal', 'shema');
	});


	$(function(){
  wl.callbacks.onFormSubmit = function ($form, res) {
        if ($form.data('next') ) {
            if(res.status == 200){
            $('#info').modal();
						$('.form1').modal('hide');
						$('.form1').parents('.modal').css('display','none');
						/*$('.modal-backdrop').css('display','none');*/
                       }else{
                           wl.callbacks.def.onFormSubmit($form, res);
                       }
              } else {
        			$('#info').modal('toggle');
                    $('#success-modal').modal();
										$('.form1').modal('hide');
										$('.form1').parents('.modal').css('display','none');
               //wl.callbacks.def.onFormSubmit($form, res);
              }
        }
	 });

});
