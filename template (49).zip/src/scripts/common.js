head.ready(function() {

 	(function() {
	    // masked input
	$("input[name='phone']").mask("+7 (999) 999-99-99");
	$("input[name='phone']").attr("placeholder", "+7 (999) 999-99-99");
	}());

	var str="";
	$("input[name='name']").on('change', function() {
	  $('.success-message').empty();
	  str = $(this).val() + ", наши менеджеры уже занимаются вашей заявкой.";
	  //alert(str);
	  $('.success-message').prepend(str);
	});

 	//по клику по кнопке присвоить свою цель для формы
	$('.callback').on('click', function() {
	  $('#myModal form').attr('data-goal', 'callback');
	});

});

/*** video play ***/



/***thank modal***/
var width = $(window).width();
var heightClient = 200;
if(width >767){
	heightClient =  $( window ).height() -230;
} else{
	heightClient =  $( window ).height() -145;
}
function height(){
	if ( heightClient >= 400 ){
		 $('#success-modal').css('height',heightClient);
	}
}
height();
$( window ).resize( height() );
