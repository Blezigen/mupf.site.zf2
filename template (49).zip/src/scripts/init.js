head.load("src/scripts/lib/jquery.js",
		 "src/scripts/lib/bootstrap.min.js",
		 "src/scripts/lib/validator.js",
		 "src/scripts/lib/jquery-ui.min.js",
		 "src/scripts/jquery.maskedinput.min.js",
		 "src/scripts/common.js");
